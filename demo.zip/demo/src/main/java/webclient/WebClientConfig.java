package webclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class WebClientConfig {
    @Autowired
    private WebClient webClient;

    public Mono<String> getDataFromOtherApp() {
        String url = "http://localhost:8080/users";
        return webClient
                .get()
                .uri(url)
                .retrieve()
                .bodyToMono(String.class);
    }

    public Mono<Void> delete(Integer id)
    {
        return webClient
                .delete()
                .uri("/employees/" +id)
                .retrieve()
                .bodyToMono(Void.class);
    }
}
