package controller;

import controller.dto.UserAdminDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import service.UserAdminService;

@RestController
@RequestMapping(value = "/users")
public class UserAdminController {
    @Autowired
    private UserAdminService userAdminService;

    @PostMapping("/add")
    public Mono<UserAdminDTO> sendPostRequest(@RequestBody UserAdminDTO user) {
        return userAdminService.saveUser(user);
    }

    @DeleteMapping("/delete")
    public Mono<Void> delete(@RequestBody Integer id) {
        return userAdminService.delete(id);
    }
}
