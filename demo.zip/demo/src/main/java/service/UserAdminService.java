package service;

import controller.dto.UserAdminDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class UserAdminService {
    @Autowired
    private WebClient webClient;
    public Mono<UserAdminDTO> saveUser(UserAdminDTO user) {
        return webClient
                .post()
                .uri("http://localhost:8080/users/add")
                .body(Mono.just(user), UserAdminDTO.class)
                .retrieve()
                .bodyToMono(UserAdminDTO.class);
    }

    public Mono<Void> delete(Integer id) {
        return webClient.delete()
                .uri("http://localhost:8080/users/delete" + id)
                .retrieve()
                .bodyToMono(Void.class);
    }

}
